package main

import (
	"game/internal/adapters/memory"
	"game/internal/usecase"
	"game/internal/world"
)

var (
	repo = memory.NewRepo()
	svc  = usecase.NewGameService(repo)
)

func initGame() {
	svc.Init(world.Build())
}

func handleCommand(cmd string) string {
	return svc.Handle(cmd)
}

func main() {
	initGame()
}
